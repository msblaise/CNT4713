<html>
<head><title>Cryptography</title>
<center>
<form action="home.php" method="POST">

<p>Text Input</p>
	<textarea name="message" rows="6" cols="25"></textarea></br>
<input type="submit" value="Encrypt"><input type="submit" value="Decrypt">
<br><input type="submit" value="Submit"></br>

<p>New Text</p><textarea name="new_message" rows="6" cols="25"></textarea></br>


</form>
</body></center>
</html>
	
<?php

// Connecting to database
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";


if (isset($_POST['Encrypt'])) {
    $rsa->loadKey($privatekey);
    $ciphertext = $rsa->encrypt($message);
    echo $ciphertext;
  }

if (isset($_POST['Decrypt'])) {
    $rsa->loadKey($publickey);
    echo $rsa->decrypt($ciphertext);
  }
   
?>
